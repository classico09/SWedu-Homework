create database hw1;

use hw1;

create table animal(
	id varchar(10),
    Dt int(8),
    Place varchar(200),
    Kind varchar(200),
    Color varchar(200),
    Age varchar(100),
    Weight varchar(100),
    Notice varchar(200),
    Sdt int(8),
    Edt int(8),
    Popfile varchar(500),
    ProcessState varchar(200),
    Sex varchar(1),
    Neuter varchar(1),
    SpecialMark varchar(500),
    CareNm varchar(100),
    CareTel varchar(100),
    CareAddr varchar(200),
    OrgNm varchar(100),
    ChargeNm varchar(100),
    Officetel varchar(100),
    NumOfRows int(10),
    PageNo int(10),
    TotalCount int(10)
);

show tables;

insert into animal(	id, Dt, Place, Kind, Color, Age, Weight, Notice, Sdt, Edt, Popfile, ProcessState, Sex, Neuter, SpecialMark, CareNm, CareTel, CareAddr, OrgNm, ChargeNm, Officetel,
	NumOfRows,
    PageNo,
    TotalCount) values (
    5,
    "20211231",
    "영도 동물병원",
    "[개] 푸들",
    "흰색",
    "2020(년생)",
    "3.2(Kg)",
    "부산-영도-2022-00001",
    20220104,
    20220114,
    "http://www.animal.go.kr/files/shelter/2021/12/202201040901435.jpg",
    "종료(반환)",
    "M",
    "N",
    "파란색 옷 착용",
    "하얀비둘기",
    "051-293-9779",
    "부산광역시 강서구 제도로 726 (강동동)",
    "부산광역시 영도구",
    "유혜정",
    "051-419-6211",
    10,
    1,
    8309
    );

select * from animal;

update animal set NumOfRows = 1000, PageNo = 1, TotalCount = 8000 where id = "1";
